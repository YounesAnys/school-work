# WinterSunRise

>is a collaboration of efforts between Mahyar Gorji, Nicolas Paré, and Parastoo Saharkhiz for the requirements of SEG3125 Lab 2 at uOttawa.
This is simply a proof of concept website composed of only HTML5, CSS3, and JS.

To run this website, simply run the following commands:

	git clone https://github.com/UglyShirtTrio/WinterSunRise.git

and open index.html with the browser of your choice.

Features we incorporated include:
--
- Responsive Design (using bootstrap)
- Javascript for the some fancy stuff
- And that's it.

It really **is** that simple to create your own *front-end only* website. All it takes is time.

Considerations going forward:
--

- Use a content management system (i.e drupal) so we don't need > 20 html pages.
- Database integration for a functional search mechanism
- A working shopping cart (http://simplecartjs.org/)