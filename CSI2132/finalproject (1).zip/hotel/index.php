
<?php

include 'settings.php';

$query = "SELECT * FROM `Tblrooms` INNER JOIN `Tblhotel` ON `Tblrooms`.`hotel_id` = `Tblhotel`.`hotel_id`;";

$link = mysqli_connect($host, $username, $password);
mysqli_select_db($link, $database);
$result = mysqli_query($link, $query);

echo "

<head>
<style>
tr:nth-child(even) {background: #DDD}
tr:nth-child(odd) {background: #FFF}
</style>
</head>
<h1>Hotel Booking</h1>
<h3>All rooms</h3>

<input type='text' id='myInput' onkeyup='myFunction()' placeholder='Names..' title='Name'>
<input type='text' id='myInputP' onkeyup='myFunctionP()' placeholder='Price..' title='Price'>
<input type='text' id='myInputR' onkeyup='myFunctionR()' placeholder='Rating..' title='Raint'>


<table id='myTable'>
        <tr class='header'>
        <th align='left'>Image</th>
          <th align='left'>Hotel</th>
          <th align='left'>Price</th>
          <th align='left'>Rating</th>
          <th align='left'>Address</th>
          <th align='left'>Book</th>
        </tr>
";

while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    echo  "
    <tr>
      <td><img src=".$row['image']." height='50px' width='50px'></td>
      <td>".$row['name']."</td>
      <td>".$row['room_price']."</td>
      <td>".$row['rating']."</td>
      <td>".$row['brand']."</td>
      <td>".$row['address']."</td>
      <td><a href='room.php?room=".$row['room_id']."'>Book</a></td>
    </tr>
    ";
}

echo "</table>

<script>
function myFunction() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById('myInput');
  filter = input.value.toUpperCase();
  table = document.getElementById('myTable');
  tr = table.getElementsByTagName('tr');
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName('td')[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = '';
      } else {
        tr[i].style.display = 'none';
      }
    }
  }
}
</script>

<script>
function myFunctionP() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById('myInputP');
  filter = input.value.toUpperCase();
  table = document.getElementById('myTable');
  tr = table.getElementsByTagName('tr');
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName('td')[2];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = '';
      } else {
        tr[i].style.display = 'none';
      }
    }
  }
}
</script>

<script>
function myFunctionR() {
  var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById('myInputR');
  filter = input.value.toUpperCase();
  table = document.getElementById('myTable');
  tr = table.getElementsByTagName('tr');
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName('td')[3];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = '';
      } else {
        tr[i].style.display = 'none';
      }
    }
  }
}
</script>

";

?>
