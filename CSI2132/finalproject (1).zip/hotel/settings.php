<?php
$username = "root";
$password = "root";
$host = "127.0.0.1";
$database = "database";
?>
