<?php

include 'settings.php';


$query = "SELECT * FROM `Tblhistory` INNER JOIN `Tblrooms` ON `Tblhistory`.`room_id` = `Tblrooms`.`room_id` INNER JOIN `Tblhotel` ON `Tblrooms`.`hotel_id` = `Tblhotel`.`hotel_id` ORDER BY  `Tblhistory`.`transaction_id` DESC LIMIT 1;";
$link = mysqli_connect($host, $username, $password);
mysqli_select_db($link, $database);
$result = mysqli_query($link, $query);

$row = mysqli_fetch_array($result, MYSQLI_ASSOC);

echo "<h1> Thank you for booking at ".$row['name'] ."</h1>";


echo "<img src='".$row['image']."' width='200px' height='200px'> <BR>";

echo "<BR>";

echo "<b>Address:</b>" . $row['address'] . "<BR><BR>";
echo "<b>Check Out: </b>" . $row['time_in'] . "<BR>";
echo "<b>Check Out: </b>" . $row['time_out'] . "<BR>";

$days = $row['invoice'] / $row['room_price'];
$rate = $row['invoice'] / $days;

echo "<b>Total: </b> ". $days . " nights * $". $rate . ".00 = $" . $row['invoice'] . ".00";


echo "<br><br><a href='index.php'> Log Out</a>"



?>
