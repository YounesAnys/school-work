<?php

include 'settings.php';


$room = $_GET['room_id'];
$in  = $_GET['date_in'];
$out  = $_GET['date_out'];


$e_in = strtotime($in);
$e_out = strtotime($out);

$e_day = 86400;


$booked = array();

for($i=$e_in;$i<$e_out;$i+= $e_day){
  array_push($booked,($e_in + $i));
}

$num_days = sizeof($booked);
$total = $num_days * $_GET['price'];

if($e_out < $e_in){//@@
  header("Location: room.php?room=".$room."&e=invalid&date_in=".$date_in."&date_out=".$date_out);
}

$user = 1;

$query = "INSERT INTO `Tblhistory` (`transaction_id`, `customer_sin`, `employees_sin`, `room_id`, `time_in`, `time_out`, `invoice`) VALUES (NULL, $user, NULL, $room, '$in', '$out', $total);";

$link = mysqli_connect($host, $username, $password);
mysqli_select_db($link, $database);
$result = mysqli_query($link, $query);
mysqli_close();

header("Location: confirm.php");




?>
