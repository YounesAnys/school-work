# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.0.1 (MySQL 5.7.25)
# Database: database
# Generation Time: 2019-04-08 01:45:52 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table Tblcustomer
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Tblcustomer`;

CREATE TABLE `Tblcustomer` (
  `customer_sin` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date_of_registration` date DEFAULT NULL,
  `full_name` text,
  PRIMARY KEY (`customer_sin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Tblcustomer` WRITE;
/*!40000 ALTER TABLE `Tblcustomer` DISABLE KEYS */;

INSERT INTO `Tblcustomer` (`customer_sin`, `date_of_registration`, `full_name`)
VALUES
	(1,NULL,'Muffy '),
	(2,NULL,'Tae'),
	(3,NULL,'Steve Jobs');

/*!40000 ALTER TABLE `Tblcustomer` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Tblemployees
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Tblemployees`;

CREATE TABLE `Tblemployees` (
  `employees_sin` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date_of_registration` date DEFAULT NULL,
  `full_name` text,
  `hotel_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`employees_sin`),
  KEY `hotel_id` (`hotel_id`),
  CONSTRAINT `tblemployees_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `Tblhotel` (`hotel_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Tblemployees` WRITE;
/*!40000 ALTER TABLE `Tblemployees` DISABLE KEYS */;

INSERT INTO `Tblemployees` (`employees_sin`, `date_of_registration`, `full_name`, `hotel_id`)
VALUES
	(1,NULL,'Philis Vance',2),
	(2,NULL,'Bob Vance',1);

/*!40000 ALTER TABLE `Tblemployees` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Tblhistory
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Tblhistory`;

CREATE TABLE `Tblhistory` (
  `transaction_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_sin` int(11) unsigned NOT NULL,
  `employees_sin` int(11) unsigned DEFAULT NULL,
  `room_id` int(11) unsigned NOT NULL,
  `time_in` date NOT NULL,
  `time_out` date NOT NULL,
  `invoice` float DEFAULT NULL,
  PRIMARY KEY (`transaction_id`),
  KEY `customer_sin` (`customer_sin`),
  KEY `employees_sin` (`employees_sin`),
  CONSTRAINT `tblhistory_ibfk_1` FOREIGN KEY (`customer_sin`) REFERENCES `Tblcustomer` (`customer_sin`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `tblhistory_ibfk_2` FOREIGN KEY (`employees_sin`) REFERENCES `Tblemployees` (`employees_sin`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Tblhistory` WRITE;
/*!40000 ALTER TABLE `Tblhistory` DISABLE KEYS */;

INSERT INTO `Tblhistory` (`transaction_id`, `customer_sin`, `employees_sin`, `room_id`, `time_in`, `time_out`, `invoice`)
VALUES
	(1,1,NULL,2,'2019-04-10','2019-04-12',100),
	(2,1,NULL,38,'2019-04-24','2019-04-25',100),
	(3,1,NULL,38,'2019-04-26','2019-04-27',100),
	(4,1,NULL,38,'2019-03-01','2019-03-03',100),
	(5,1,NULL,38,'2019-04-01','2019-04-03',100),
	(6,1,NULL,33,'2018-08-08','2018-08-10',100),
	(7,1,NULL,38,'2019-03-11','2019-03-12',100),
	(8,1,NULL,38,'2019-04-11','2019-04-12',100),
	(9,1,NULL,38,'2017-04-11','2017-04-12',100),
	(10,1,NULL,4,'2019-04-25','2019-04-26',100),
	(11,1,NULL,4,'2019-05-03','2019-05-04',100),
	(12,1,NULL,4,'2019-05-05','2019-05-13',800),
	(13,1,NULL,26,'2019-04-29','2019-04-30',443),
	(14,1,NULL,4,'2019-04-14','2019-04-23',900);

/*!40000 ALTER TABLE `Tblhistory` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Tblhotel
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Tblhotel`;

CREATE TABLE `Tblhotel` (
  `hotel_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `rating` tinyint(5) NOT NULL,
  `num_of_rooms` int(11) DEFAULT NULL,
  `name` text,
  `address` text,
  `brand` varchar(40) NOT NULL DEFAULT '',
  `image` text,
  PRIMARY KEY (`hotel_id`),
  KEY `brand` (`brand`),
  CONSTRAINT `tblhotel_ibfk_1` FOREIGN KEY (`brand`) REFERENCES `Tblhotel_chain` (`brand`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Tblhotel` WRITE;
/*!40000 ALTER TABLE `Tblhotel` DISABLE KEYS */;

INSERT INTO `Tblhotel` (`hotel_id`, `rating`, `num_of_rooms`, `name`, `address`, `brand`, `image`)
VALUES
	(1,5,NULL,'CountryMuffRiverside','12 Spadina Cres.','countymuff','https://i.imgur.com/QfZ5i7e.jpg'),
	(2,4,NULL,'TaebearByward','2014 Forest Hills Dr.','taebear','https://i.imgur.com/zoKrRxF.jpg'),
	(3,5,NULL,'AbdullahBarrhaven','55 Formal Ave.','abdullah','https://i.imgur.com/aK05mAT.jpg'),
	(4,2,NULL,'HamiltonVancouver','66 Excellence Blvd.','hamilton','https://i.imgur.com/aFyHZmF.jpg'),
	(5,5,NULL,'BluestownNashville','11 Nashville Rd.','bluestown','https://i.imgur.com/2lxW8ZK.jpg'),
	(6,4,NULL,'CountyMuffVancouver','989 Cresthaven Dr.','countymuff','https://i.imgur.com/mfuTTYp.jpg'),
	(7,3,NULL,'TaebearKorea','54 Lorry Blvd.','taebear','https://i.imgur.com/mVLidKn.jpg'),
	(8,4,NULL,'AbdullahVancouver','13 Uranus Rd.','abdullah','https://i.imgur.com/kX0u4FH.jpg'),
	(9,1,NULL,'HamiltonOttawa','81 Nicobella Dr.','hamilton','https://i.imgur.com/g5p0Ugr.jpg'),
	(10,4,NULL,'BluestownOttawa','1 Consuella St.','bluestown','https://i.imgur.com/4O8Jcuo.jpg'),
	(11,3,NULL,'CountyMuffJapan','13 Hayato Rd.','countymuff','https://i.imgur.com/xNMBzaE.jpg'),
	(12,2,NULL,'TaebearKingston','4228 Lovers Ave.','taebear','https://i.imgur.com/9k4pYJK.jpg'),
	(13,2,NULL,'AbdullahWilbrod','990 Addo Cres.','abdullah','https://i.imgur.com/TFsVQUZ.gif'),
	(14,3,NULL,'HamiltonMauve','699 Huda Place.','hamilton','https://i.imgur.com/Fv1bK6j.jpg'),
	(15,1,NULL,'BluestownJive','420 Urmami Rd.','bluestown','https://i.imgur.com/FKIM4Zv.jpg');

/*!40000 ALTER TABLE `Tblhotel` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Tblhotel_chain
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Tblhotel_chain`;

CREATE TABLE `Tblhotel_chain` (
  `brand` varchar(40) NOT NULL DEFAULT '',
  `address` text,
  `phone` text,
  `num_of_hotels` int(11) DEFAULT NULL,
  `email` text,
  PRIMARY KEY (`brand`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Tblhotel_chain` WRITE;
/*!40000 ALTER TABLE `Tblhotel_chain` DISABLE KEYS */;

INSERT INTO `Tblhotel_chain` (`brand`, `address`, `phone`, `num_of_hotels`, `email`)
VALUES
	('abdullah','50 Excellence Ave','6131234040',NULL,'abdullah@iace9.com'),
	('bluestown','22 Jazzy Dr','4678888080',NULL,'music@gmail.com'),
	('countymuff','44 Farrhaven Ave','6137774477',NULL,'muffy@muffy.com'),
	('hamilton','400 Downtown Ave','6131010101',NULL,'hamilton@gmail.com'),
	('taebear','44 Cartyay Ave','6132886969',NULL,'tae@tay.com');

/*!40000 ALTER TABLE `Tblhotel_chain` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table Tblrooms
# ------------------------------------------------------------

DROP TABLE IF EXISTS `Tblrooms`;

CREATE TABLE `Tblrooms` (
  `room_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `room_num` int(11) unsigned DEFAULT NULL,
  `room_price` float unsigned DEFAULT NULL,
  `spec_extendable` tinyint(1) DEFAULT NULL,
  `spec_tv` tinyint(1) DEFAULT NULL,
  `spec_fridge` tinyint(1) DEFAULT NULL,
  `spec_problems` tinyint(1) DEFAULT NULL,
  `spec_ac` tinyint(1) DEFAULT NULL,
  `hotel_id` int(11) unsigned NOT NULL,
  PRIMARY KEY (`room_id`),
  KEY `hotel_id` (`hotel_id`),
  CONSTRAINT `tblrooms_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `Tblhotel` (`hotel_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `Tblrooms` WRITE;
/*!40000 ALTER TABLE `Tblrooms` DISABLE KEYS */;

INSERT INTO `Tblrooms` (`room_id`, `room_num`, `room_price`, `spec_extendable`, `spec_tv`, `spec_fridge`, `spec_problems`, `spec_ac`, `hotel_id`)
VALUES
	(1,223,333,0,1,0,0,0,6),
	(2,20,313,0,1,1,0,0,13),
	(3,288,522,1,1,1,1,0,4),
	(4,22,100,0,0,0,0,0,1),
	(5,44,100,0,0,0,0,0,2),
	(6,95,352,0,1,0,0,1,11),
	(7,3,419,1,0,0,0,0,9),
	(8,3,432,1,0,0,0,0,2),
	(9,35,284,1,1,1,1,0,2),
	(10,89,291,1,0,1,0,1,3),
	(11,131,417,0,0,1,0,1,1),
	(12,170,552,1,1,1,0,0,14),
	(13,47,249,1,0,0,1,1,7),
	(14,288,296,0,1,1,0,1,3),
	(15,111,515,1,1,0,1,1,5),
	(16,294,264,1,1,0,0,0,7),
	(17,267,404,1,1,1,1,1,3),
	(18,122,242,0,1,1,1,1,12),
	(19,209,287,0,1,0,1,1,10),
	(20,62,223,0,1,0,0,1,5),
	(21,47,494,0,1,0,1,1,15),
	(22,75,540,1,0,1,1,1,2),
	(23,72,600,1,1,1,1,0,6),
	(24,77,201,1,1,0,0,1,7),
	(25,296,472,0,1,1,0,1,3),
	(26,201,443,1,0,0,0,0,1),
	(27,249,475,0,1,1,0,0,1),
	(28,272,570,0,1,1,0,1,10),
	(29,65,330,0,1,0,0,1,11),
	(30,22,465,0,1,0,0,0,7),
	(31,70,306,0,1,0,1,1,13),
	(32,234,496,1,1,0,0,1,2),
	(33,281,440,0,1,0,0,1,1),
	(34,148,364,0,1,0,1,0,6),
	(35,233,582,0,0,1,1,1,11),
	(36,185,410,1,0,0,0,1,13),
	(37,269,238,0,0,1,0,0,14),
	(38,54,212,1,0,0,0,0,6),
	(39,47,563,1,0,1,1,0,4);

/*!40000 ALTER TABLE `Tblrooms` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
