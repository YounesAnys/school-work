
public class Chopstick {
	private int ID;
	private boolean free;

	Chopstick(int ID) {
		this.ID = ID;
		free = true;
	}

	synchronized boolean take() {
		
		
		boolean result;
		
		if (!free){
			// the mutex is not free, we must wait
			try{
				wait(1000);
			
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
		}
		
		// Was it freed during the time we were blocked?		
		result = free;
		free = false;
		
		return result;
		
	}

	synchronized void release() {
		free = true;
		notify();
	}

	public int getID() {
		return(ID);
	}
}