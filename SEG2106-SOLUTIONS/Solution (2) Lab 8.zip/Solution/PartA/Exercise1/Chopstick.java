
public class Chopstick {
	private int ID;
	private boolean free;
	
	Chopstick(int ID) {
		this.ID = ID;
		free = true;
	}
	
	synchronized void take() {
		while(!free) {
			try {
				wait();
			} 
			catch(InterruptedException e) {
				System.out.println(e);
			}
		}
	free = false;
	}
	
	synchronized void release() {
		free = true;
		notify();
	}
	
	public int getID() {
		return(ID);
	}
}
