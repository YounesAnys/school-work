package SEG2106.core;

/*PLEASE DO NOT EDIT THIS CODE*/
/*This code was generated using the UMPLE 1.25.0-89f4041 modeling language!*/



// line 2 "model.ump"
// line 157 "model.ump"
public class TrafficLight implements EventHandler
{

  //------------------------
  // MEMBER VARIABLES
  //------------------------

  //TrafficLight State Machines
  public enum Status { lowTraffic, moderateTraffic, highTraffic }
  public enum StatusLowTraffic { Null, northAndSouthArrow, northAndSouthGreen, northAndSouthYellow, westAndEastGreen, westAndEastYellow }
  public enum StatusModerateTraffic { Null, northGreenAndArrow, northYellow, southGreenAndArrow, southYellow, westAndEastGreen, westAndEastYellow }
  public enum StatusHighTraffic { Null, northGreenAndArrow, northYellow, southGreenAndArrow, southYellow, westGreenAndArrow, westAndEastGreen, westAndEastYellow }
  private Status status;
  private StatusLowTraffic statusLowTraffic;
  private StatusModerateTraffic statusModerateTraffic;
  private StatusHighTraffic statusHighTraffic;

  //------------------------
  // CONSTRUCTOR
  //------------------------

  private TrafficLightManager trafficLightManager; 
  public TrafficLight(TrafficLightManager trafficLightManager)
  {
      
    this.trafficLightManager = trafficLightManager;  
    setStatusLowTraffic(StatusLowTraffic.Null);
    setStatusModerateTraffic(StatusModerateTraffic.Null);
    setStatusHighTraffic(StatusHighTraffic.Null);
    setStatus(Status.lowTraffic);
    
    trafficLightManager.addEventHandler(this);
  }

  //------------------------
  // INTERFACE
  //------------------------

  public String getStatusFullName()
  {
    String answer = status.toString();
    if (statusLowTraffic != StatusLowTraffic.Null) { answer += "." + statusLowTraffic.toString(); }
    if (statusModerateTraffic != StatusModerateTraffic.Null) { answer += "." + statusModerateTraffic.toString(); }
    if (statusHighTraffic != StatusHighTraffic.Null) { answer += "." + statusHighTraffic.toString(); }
    return answer;
  }

  public Status getStatus()
  {
    return status;
  }

  public StatusLowTraffic getStatusLowTraffic()
  {
    return statusLowTraffic;
  }

  public StatusModerateTraffic getStatusModerateTraffic()
  {
    return statusModerateTraffic;
  }

  public StatusHighTraffic getStatusHighTraffic()
  {
    return statusHighTraffic;
  }

  public boolean moderateTraffic()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case lowTraffic:
        exitStatus();
        setStatus(Status.moderateTraffic);
        wasEventProcessed = true;
        break;
      case highTraffic:
        exitStatus();
        setStatus(Status.moderateTraffic);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean highTraffic()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case lowTraffic:
        exitStatus();
        setStatus(Status.highTraffic);
        wasEventProcessed = true;
        break;
      case moderateTraffic:
        exitStatus();
        setStatus(Status.highTraffic);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean lowTraffic()
  {
    boolean wasEventProcessed = false;
    
    Status aStatus = status;
    switch (aStatus)
    {
      case moderateTraffic:
        exitStatus();
        setStatus(Status.moderateTraffic);
        wasEventProcessed = true;
        break;
      case highTraffic:
        exitStatus();
        setStatus(Status.lowTraffic);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private boolean enterLowTraffic()
  {
    boolean wasEventProcessed = false;
    
    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
    switch (aStatusLowTraffic)
    {
      case Null:
        setStatusLowTraffic(StatusLowTraffic.northAndSouthArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private boolean exitLowTraffic()
  {
    boolean wasEventProcessed = false;
    
    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
    switch (aStatusLowTraffic)
    {
      case northAndSouthArrow:
        setStatusLowTraffic(StatusLowTraffic.Null);
        wasEventProcessed = true;
        break;
      case northAndSouthGreen:
        setStatusLowTraffic(StatusLowTraffic.Null);
        wasEventProcessed = true;
        break;
      case northAndSouthYellow:
        setStatusLowTraffic(StatusLowTraffic.Null);
        wasEventProcessed = true;
        break;
      case westAndEastGreen:
        setStatusLowTraffic(StatusLowTraffic.Null);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        setStatusLowTraffic(StatusLowTraffic.Null);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean timerGreen()
  {
    boolean wasEventProcessed = false;
    
    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
    switch (aStatusLowTraffic)
    {
      case northAndSouthArrow:
        setStatusLowTraffic(StatusLowTraffic.northAndSouthGreen);
        wasEventProcessed = true;
        break;
      case northAndSouthGreen:
        setStatusLowTraffic(StatusLowTraffic.northAndSouthYellow);
        wasEventProcessed = true;
        break;
      case westAndEastGreen:
        setStatusLowTraffic(StatusLowTraffic.westAndEastYellow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aStatusModerateTraffic)
    {
      case northGreenAndArrow:
        setStatusModerateTraffic(StatusModerateTraffic.northYellow);
        wasEventProcessed = true;
        break;
      case southGreenAndArrow:
        setStatusModerateTraffic(StatusModerateTraffic.southYellow);
        wasEventProcessed = true;
        break;
      case westAndEastGreen:
        setStatusModerateTraffic(StatusModerateTraffic.westAndEastYellow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aStatusHighTraffic)
    {
      case northGreenAndArrow:
        setStatusHighTraffic(StatusHighTraffic.northYellow);
        wasEventProcessed = true;
        break;
      case southGreenAndArrow:
        setStatusHighTraffic(StatusHighTraffic.southYellow);
        wasEventProcessed = true;
        break;
      case westGreenAndArrow:
        setStatusHighTraffic(StatusHighTraffic.westAndEastGreen);
        wasEventProcessed = true;
        break;
      case westAndEastGreen:
        setStatusHighTraffic(StatusHighTraffic.westAndEastYellow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  public boolean timerYellow()
  {
    boolean wasEventProcessed = false;
    
    StatusLowTraffic aStatusLowTraffic = statusLowTraffic;
    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
    switch (aStatusLowTraffic)
    {
      case northAndSouthYellow:
        setStatusLowTraffic(StatusLowTraffic.westAndEastGreen);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        setStatusLowTraffic(StatusLowTraffic.northAndSouthArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aStatusModerateTraffic)
    {
      case northYellow:
        setStatusModerateTraffic(StatusModerateTraffic.southGreenAndArrow);
        wasEventProcessed = true;
        break;
      case southYellow:
        setStatusModerateTraffic(StatusModerateTraffic.westAndEastGreen);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        setStatusModerateTraffic(StatusModerateTraffic.northGreenAndArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    switch (aStatusHighTraffic)
    {
      case northYellow:
        setStatusHighTraffic(StatusHighTraffic.southGreenAndArrow);
        wasEventProcessed = true;
        break;
      case southYellow:
        setStatusHighTraffic(StatusHighTraffic.westGreenAndArrow);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        setStatusHighTraffic(StatusHighTraffic.northGreenAndArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private boolean enterModerateTraffic()
  {
    boolean wasEventProcessed = false;
    
    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
    switch (aStatusModerateTraffic)
    {
      case Null:
        setStatusModerateTraffic(StatusModerateTraffic.northGreenAndArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private boolean exitModerateTraffic()
  {
    boolean wasEventProcessed = false;
    
    StatusModerateTraffic aStatusModerateTraffic = statusModerateTraffic;
    switch (aStatusModerateTraffic)
    {
      case northGreenAndArrow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        wasEventProcessed = true;
        break;
      case northYellow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        wasEventProcessed = true;
        break;
      case southGreenAndArrow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        wasEventProcessed = true;
        break;
      case southYellow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        wasEventProcessed = true;
        break;
      case westAndEastGreen:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        setStatusModerateTraffic(StatusModerateTraffic.Null);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private boolean enterHighTraffic()
  {
    boolean wasEventProcessed = false;
    
    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
    switch (aStatusHighTraffic)
    {
      case Null:
        setStatusHighTraffic(StatusHighTraffic.northGreenAndArrow);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private boolean exitHighTraffic()
  {
    boolean wasEventProcessed = false;
    
    StatusHighTraffic aStatusHighTraffic = statusHighTraffic;
    switch (aStatusHighTraffic)
    {
      case northGreenAndArrow:
        setStatusHighTraffic(StatusHighTraffic.Null);
        wasEventProcessed = true;
        break;
      case northYellow:
        setStatusHighTraffic(StatusHighTraffic.Null);
        wasEventProcessed = true;
        break;
      case southGreenAndArrow:
        setStatusHighTraffic(StatusHighTraffic.Null);
        wasEventProcessed = true;
        break;
      case southYellow:
        setStatusHighTraffic(StatusHighTraffic.Null);
        wasEventProcessed = true;
        break;
      case westGreenAndArrow:
        setStatusHighTraffic(StatusHighTraffic.Null);
        wasEventProcessed = true;
        break;
      case westAndEastGreen:
        setStatusHighTraffic(StatusHighTraffic.Null);
        wasEventProcessed = true;
        break;
      case westAndEastYellow:
        setStatusHighTraffic(StatusHighTraffic.Null);
        wasEventProcessed = true;
        break;
      default:
        // Other states do respond to this event
    }

    return wasEventProcessed;
  }

  private void exitStatus()
  {
    switch(status)
    {
      case lowTraffic:
        exitLowTraffic();
        break;
      case moderateTraffic:
        exitModerateTraffic();
        break;
      case highTraffic:
        exitHighTraffic();
        break;
    }
  }

  private void setStatus(Status aStatus)
  {
    status = aStatus;

    // entry actions and do activities
    switch(status)
    {
      case lowTraffic:
        if (statusLowTraffic == StatusLowTraffic.Null) { setStatusLowTraffic(StatusLowTraffic.northAndSouthArrow); }
        break;
      case moderateTraffic:
        if (statusModerateTraffic == StatusModerateTraffic.Null) { setStatusModerateTraffic(StatusModerateTraffic.northGreenAndArrow); }
        break;
      case highTraffic:
        if (statusHighTraffic == StatusHighTraffic.Null) { setStatusHighTraffic(StatusHighTraffic.northGreenAndArrow); }
        break;
    }
  }

  private void setStatusLowTraffic(StatusLowTraffic aStatusLowTraffic)
  {
    statusLowTraffic = aStatusLowTraffic;
    if (status != Status.lowTraffic && aStatusLowTraffic != StatusLowTraffic.Null) { setStatus(Status.lowTraffic); }

    // entry actions and do activities
    switch(statusLowTraffic)
    {
      case northAndSouthArrow:
        // line 8 "model.ump"
        trafficLightManager.northArrow();
        // line 9 "model.ump"
        trafficLightManager.southArrow();
        // line 10 "model.ump"
        trafficLightManager.westRed();
        // line 11 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northAndSouthGreen:
        // line 15 "model.ump"
        trafficLightManager.northGreen();
        // line 16 "model.ump"
        trafficLightManager.southGreen();
        // line 17 "model.ump"
        trafficLightManager.westRed();
        // line 18 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northAndSouthYellow:
        // line 22 "model.ump"
        trafficLightManager.northYellow();
        // line 23 "model.ump"
        trafficLightManager.southYellow();
        // line 24 "model.ump"
        trafficLightManager.westRed();
        // line 25 "model.ump"
        trafficLightManager.eastRed();
        break;
      case westAndEastGreen:
        // line 30 "model.ump"
        trafficLightManager.northRed();
        // line 31 "model.ump"
        trafficLightManager.southRed();
        // line 32 "model.ump"
        trafficLightManager.westGreen();
        // line 33 "model.ump"
        trafficLightManager.eastGreen();
        break;
      case westAndEastYellow:
        // line 38 "model.ump"
        trafficLightManager.northRed();
        // line 39 "model.ump"
        trafficLightManager.southRed();
        // line 40 "model.ump"
        trafficLightManager.westYellow();
        // line 41 "model.ump"
        trafficLightManager.eastYellow();
        break;
    }
  }

  private void setStatusModerateTraffic(StatusModerateTraffic aStatusModerateTraffic)
  {
    statusModerateTraffic = aStatusModerateTraffic;
    if (status != Status.moderateTraffic && aStatusModerateTraffic != StatusModerateTraffic.Null) { setStatus(Status.moderateTraffic); }

    // entry actions and do activities
    switch(statusModerateTraffic)
    {
      case northGreenAndArrow:
        // line 51 "model.ump"
        trafficLightManager.northGreenAndArrow();
        // line 52 "model.ump"
        trafficLightManager.southRed();
        // line 53 "model.ump"
        trafficLightManager.westRed();
        // line 54 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northYellow:
        // line 59 "model.ump"
        trafficLightManager.northYellow();
        // line 60 "model.ump"
        trafficLightManager.southRed();
        // line 61 "model.ump"
        trafficLightManager.westRed();
        // line 62 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southGreenAndArrow:
        // line 66 "model.ump"
        trafficLightManager.northRed();
        // line 67 "model.ump"
        trafficLightManager.southGreenAndArrow();
        // line 68 "model.ump"
        trafficLightManager.westRed();
        // line 69 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southYellow:
        // line 73 "model.ump"
        trafficLightManager.northRed();
        // line 74 "model.ump"
        trafficLightManager.southYellow();
        // line 75 "model.ump"
        trafficLightManager.westRed();
        // line 76 "model.ump"
        trafficLightManager.eastRed();
        break;
      case westAndEastGreen:
        // line 80 "model.ump"
        trafficLightManager.northRed();
        // line 81 "model.ump"
        trafficLightManager.southRed();
        // line 82 "model.ump"
        trafficLightManager.westGreen();
        // line 83 "model.ump"
        trafficLightManager.eastGreen();
        break;
      case westAndEastYellow:
        // line 87 "model.ump"
        trafficLightManager.northRed();
        // line 88 "model.ump"
        trafficLightManager.southRed();
        // line 89 "model.ump"
        trafficLightManager.westYellow();
        // line 90 "model.ump"
        trafficLightManager.eastYellow();
        break;
    }
  }

  private void setStatusHighTraffic(StatusHighTraffic aStatusHighTraffic)
  {
    statusHighTraffic = aStatusHighTraffic;
    if (status != Status.highTraffic && aStatusHighTraffic != StatusHighTraffic.Null) { setStatus(Status.highTraffic); }

    // entry actions and do activities
    switch(statusHighTraffic)
    {
      case northGreenAndArrow:
        // line 100 "model.ump"
        trafficLightManager.northGreenAndArrow();
        // line 101 "model.ump"
        trafficLightManager.southRed();
        // line 102 "model.ump"
        trafficLightManager.westRed();
        // line 103 "model.ump"
        trafficLightManager.eastRed();
        break;
      case northYellow:
        // line 107 "model.ump"
        trafficLightManager.northYellow();
        // line 108 "model.ump"
        trafficLightManager.southRed();
        // line 109 "model.ump"
        trafficLightManager.westRed();
        // line 110 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southGreenAndArrow:
        // line 114 "model.ump"
        trafficLightManager.northRed();
        // line 115 "model.ump"
        trafficLightManager.southGreenAndArrow();
        // line 116 "model.ump"
        trafficLightManager.westRed();
        // line 117 "model.ump"
        trafficLightManager.eastRed();
        break;
      case southYellow:
        // line 121 "model.ump"
        trafficLightManager.northRed();
        // line 122 "model.ump"
        trafficLightManager.southYellow();
        // line 123 "model.ump"
        trafficLightManager.westRed();
        // line 124 "model.ump"
        trafficLightManager.eastRed();
        break;
      case westGreenAndArrow:
        // line 129 "model.ump"
        trafficLightManager.northRed();
        // line 130 "model.ump"
        trafficLightManager.southRed();
        // line 131 "model.ump"
        trafficLightManager.westGreenAndArrow();
        // line 132 "model.ump"
        trafficLightManager.eastRed();
        break;
      case westAndEastGreen:
        // line 136 "model.ump"
        trafficLightManager.northRed();
        // line 137 "model.ump"
        trafficLightManager.southRed();
        // line 138 "model.ump"
        trafficLightManager.westGreen();
        // line 139 "model.ump"
        trafficLightManager.eastGreen();
        break;
      case westAndEastYellow:
        // line 143 "model.ump"
        trafficLightManager.northRed();
        // line 144 "model.ump"
        trafficLightManager.southRed();
        // line 145 "model.ump"
        trafficLightManager.westYellow();
        // line 146 "model.ump"
        trafficLightManager.eastYellow();
        break;
    }
  }

  public void delete()
  {}

}