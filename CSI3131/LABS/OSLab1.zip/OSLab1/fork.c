#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <unistd.h>
int main()
{
	pid_t pid;
	printf ("fork \n");
	/* fork a child process, must be called 5 times. Note: exec + fork combo, explained by prof on May 14th 2018 */
	for(int i = 0; i <5; i++){
	pid = fork();
		if (pid < 0) {
		/* error occurred */
		fprintf(stderr, "Fork Failed");
		return 1;
		}
		else if (pid == 0)
		{
			/* child process, calls ls function */
			execlp("/bin/ls","ls",NULL);
			sleep(1);
		}
		else {
		/* parent process */
		/* parent will wait for the child to complete */
		wait(NULL);
		printf("Child Complete! ");
		}
	}
	return 0;
}
	
	